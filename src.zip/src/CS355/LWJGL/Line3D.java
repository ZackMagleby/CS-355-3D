package CS355.LWJGL;

/**
 *
 * @author Brennan Smith
 */
public class Line3D 
{
    public Point3D start;
    public Point3D end;
    public Line3D(Point3D s, Point3D e)
    {
        start = s;
        end = e;
    }

}
